"use strict";
/*
declared arrays
    Ciara Viar
    April 6, 2021
*/
var item =  ["Escape Winter in Punta Cana",
 "Las Vegas", 
 "Alaskan Cabin Adventure"];

var price = [500, 334, 400];

var qty = [1,1,1];


