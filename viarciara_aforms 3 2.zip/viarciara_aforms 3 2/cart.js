
/*
Ciara Viar
April 6, 2021
*/
"use strict";

var subtotal = 0;

var cartHTML = "<table><thead><tr><th>Item Description</th><th>Price</th><th>Qty</th><th>Total</th></tr></thead><tbody>";

for(var i = 0; i<item.length; i++) {
    var cost = price[i]qty[i];
    cartHTML = cartHTML + "<tr><td>" + item[i] + "</td>";
    cartHTML = cartHTML + "<td>$" + price[i] + "</td>";
    cartHTML = cartHTML + "<td>" + qty[i] + "</td>";
    cartHTML = cartHTML + "<td>$" + cost + "</td></tr>";
    subtotal+=cost;
}


var shipCost = Math.round(subtotal0.05); 

var orderTotal = subtotal + shipCost; shipCost+= ".00";

cartHTML += "</tbody><tfoot><tr><td colspan ='3'>Subtotal</td><td>$"+subtotal+"</td></tr>";

cartHTML += "<tr><td colspan='3'>Shipping</td><td>$"+shipCost+"</td></tr>";

cartHTML += "<tr><td colspan='3'>Total</td><td>$"+orderTotal+"</td></tr></tfoot></table>";

document.getElementById("cart").innerHTML = cartHTML;

var now = new Date();

var dateShip = now.getDate() + 3;

now.setDate(dateShip);

document.getElementById("sdate").innerHTML = "Order placed today will be shipped by "+ now.toLocaleDateString();
       
